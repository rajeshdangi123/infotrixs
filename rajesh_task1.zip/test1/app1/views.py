from django.shortcuts import render,redirect
from django.http import HttpResponse
from app1.modals.customer import Customer
from django.contrib.auth.hashers import check_password,make_password
from django.contrib import messages #import messages
# Create your views here.
def home(request):
    return render(request,"app1/base.html")

def singup1(request):
    if request.method =="GET":
        return render(request,'app1/singup.html')
    else:
        messages.success(request,"welcome to contact")
        postdata=request.POST
        user_name=postdata.get("user_name")
        first_name=postdata.get("first_name")
        last_name=postdata.get('last_name')
        email_field=postdata.get('email_field')
        phone_number=postdata.get('phone_number')
        password=postdata.get('password')
        #password=make_password(password1)
        print(user_name,first_name,last_name,email_field,password)
        my_user=Customer(user_name=user_name,first_name=first_name,last_name=last_name,
                        phone_number=phone_number, email_field=email_field,password=password)
        if len(first_name)<4:
            return render(request,'app1/singup.html')
        elif (not first_name):
            return render(request,'app1/singup.html')
        elif my_user.isExists():
            return HttpResponse("email alredy register ")
        else:
           
            my_user.password=make_password(my_user.password)
            my_user.register()
            return render(request,'app1/login.html')
        
def login1(request):
    if request.method =="GET":

        return render(request,'app1/login.html')
    else:
        postdata=request.POST
        email_field=postdata.get('email_field')
        password=postdata.get('password')
       
        print("hello1",email_field,password)  
        customer=Customer.get_customer_by_email(email_field)
        print("hello2",customer)
        
        if customer:
            flag=check_password(password,customer.password)
            print("hello3",flag)
            if flag:
                request.session['customer']=customer.id
                #request.session['email_field']=customer.email_field
                print("hello4")

                return redirect('home')
                print("hello")
            else:
                return  HttpResponse("Email or Password invalid !!")
     
        print(email_field,password)  
        return render(request,'app1/login.html')
        # user=Customer.objects.get(email_field=email_field)
        # print(user)
#         # if customer is None:
            
#         #     #flag=check_password(password,customer.password1)
#         #     print("all ok")


def log_out(request):

    request.session.clear()
    return redirect('login1')