from .customer import Customer





#  {% if user.is_authenticated  %} login {{request.user}}
#                 {% if user .%}
# {% else %}
# {% endif %}